* Rename to ``hr_timesheet_time_control``.
* Move to `OCA/timesheet <https://github.com/OCA/timesheet>`__.
