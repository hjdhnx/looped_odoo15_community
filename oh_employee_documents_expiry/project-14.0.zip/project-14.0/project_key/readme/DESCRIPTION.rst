This module provides functionality to uniquely identify projects and tasks by simple ``key`` field.
