This module makes the start and end date of projects editable:

Features:

* Change start date and deadline of projects
* Shows the deadline in the project kanban view
* Show the start date and deadline of the project on the task form view
