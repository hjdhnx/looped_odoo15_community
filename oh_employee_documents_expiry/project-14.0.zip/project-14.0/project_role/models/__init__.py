# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

from . import res_config_settings
from . import res_company
from . import project_role
from . import project_assignment
from . import project_project
