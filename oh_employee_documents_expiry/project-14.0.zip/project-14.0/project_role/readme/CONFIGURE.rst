To configure the list of roles avalable:

#. Go to *Project > Configuration > Project Roles*
#. Add/remove roles according to your business processes

To manage assignments on particular project:

#. Go to *Project > Projects*
#. Open project of interest
#. Click on *Assignments* smart-button
#. Add/remove assignments as needed

To manage assignments:

#. Go to *Project > Assignments*
#. Add/remove assignments as needed

Also, it's recommended to consider using ``web_m2x_options`` module in order to
avoid unneeded creation of roles and projects using Quick Create action by
setting the ``web_m2x_options.create`` system parameter to ``False``.
