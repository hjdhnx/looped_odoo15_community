After installing this module you can assign stage tasks in project stage tab
and you can check the default stages for new projects as previously done in
Odoo 8.0.
