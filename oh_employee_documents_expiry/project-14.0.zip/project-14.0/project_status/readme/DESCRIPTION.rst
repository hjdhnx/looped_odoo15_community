This module provides a project status on projects.
