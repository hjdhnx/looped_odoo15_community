To use this module, you need to:

#. Have Manager rights for Project group to edit projects and project templates.
#. Convert project to a project template by setting the "Is Template?" field on any project.
#. View Templates via the Template filter.
#. Use the "Create Project from Template" link in the drop down menu on each template while in the Kanban view or the button on the project template form.
