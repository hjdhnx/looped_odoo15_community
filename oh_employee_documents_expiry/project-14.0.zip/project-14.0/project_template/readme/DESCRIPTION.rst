This module adds templates for projects.
