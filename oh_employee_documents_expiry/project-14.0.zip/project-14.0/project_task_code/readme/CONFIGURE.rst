To change the task code sequence, you must:

#. Activate the developer mode.
#. Go to Settings > Technical > Sequences & Identifiers > Sequences.
#. Click on "Task code" sequence to edit.
